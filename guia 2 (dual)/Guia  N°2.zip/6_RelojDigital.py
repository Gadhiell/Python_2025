"""Camilo y Karla"""

for H in range(24):
    for M in range(60):
        for S in range(60):
            
     # Imprimir la hora actual
            print(f"{H}:{M}:{S}")
            print(f"{H}:{M}:{S}")